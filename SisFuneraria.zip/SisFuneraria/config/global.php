<?php 
//Ip de la pc servidor de base de datos
define("DB_HOST","localhost");

//Nombre de la base de datos
define("DB_NAME", "id17510214_sistemabiblioteca");

//Usuario de la base de datos
define("DB_USERNAME", "id17510214_root");

//Contraseña del usuario de la base de datos
define("DB_PASSWORD", "h6@XVb3{bpEip2go");

//definimos la codificación de los caracteres
define("DB_ENCODE","utf8");

//Definimos una constante como nombre del proyecto
define("PRO_NOMBRE","sistemabiblioteca");
?>